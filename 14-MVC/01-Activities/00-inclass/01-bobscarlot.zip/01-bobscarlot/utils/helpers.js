module.exports = {
  carLinkTitle: function (make, model, url) {
    return `Car Model ${model} by ${make}`;
  },
};
